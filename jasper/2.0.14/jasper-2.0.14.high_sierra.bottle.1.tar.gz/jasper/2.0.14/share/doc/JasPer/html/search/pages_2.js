var searchData=
[
  ['installation',['Installation',['../install.html',1,'getting_started']]]
];
